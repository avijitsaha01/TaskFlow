<?php
    $due = $task->due_date;
    $dueClass = '';
    $dueLabel = $due ? $due->format('M j') : '';

    if ($due && ! $task->is_completed) {
        if ($due->isToday()) {
            $dueClass = 'today';
            $dueLabel = 'Today';
        } elseif ($due->isTomorrow()) {
            $dueClass = 'soon';
            $dueLabel = 'Tomorrow';
        } elseif ($due->isPast()) {
            $dueClass = 'overdue';
        }
    }
?>

<article class="task <?php echo e($task->is_completed ? 'done' : ''); ?>"
    data-task-id="<?php echo e($task->id); ?>"
    data-title="<?php echo e($task->title); ?>"
    data-description="<?php echo e($task->description); ?>"
    data-priority="<?php echo e($task->priority); ?>"
    data-due="<?php echo e($due ? $due->format('Y-m-d') : ''); ?>">

    
    <form action="<?php echo e(route('tasks.toggle', $task)); ?>" method="POST" style="margin:0;display:inline">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PATCH'); ?>
        <button type="submit" class="check <?php echo e($task->is_completed ? 'done' : ''); ?>"
                title="<?php echo e($task->is_completed ? 'Reopen task' : 'Mark complete'); ?>"
                aria-label="<?php echo e($task->is_completed ? 'Reopen task' : 'Mark complete'); ?>">
            <?php echo e($task->is_completed ? '✓' : ''); ?>

        </button>
    </form>

    
    <div class="task-body">
        <a href="<?php echo e(route('tasks.show', $task)); ?>" class="task-link">
            <div class="task-title"><?php echo e($task->title); ?></div>
        </a>
        <div class="meta">
            <?php echo $__env->make('components.priority-badge', ['priority' => $task->priority], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <?php if($task->status === 'in_progress'): ?>
                <span class="tag status-progress">In progress</span>
            <?php endif; ?>

            <?php if($due): ?>
                <span class="due <?php echo e($dueClass); ?>" title="Due <?php echo e($due->format('F j, Y')); ?>">
                    <?php echo e($dueClass === 'overdue' ? 'Overdue · ' : ''); ?><?php echo e($dueLabel); ?>

                </span>
            <?php endif; ?>

            <?php if($task->description): ?>
                <span class="task-snippet"><?php echo e(Str::limit($task->description, 70)); ?></span>
            <?php endif; ?>
        </div>
    </div>

    
    <div class="actions">
        <button type="button" class="icon" onclick="openModal(<?php echo e($task->id); ?>)" title="Edit task" aria-label="Edit task">Edit</button>
        <button type="button" class="icon task-delete" onclick="confirmDelete(<?php echo e($task->id); ?>)" title="Delete task" aria-label="Delete task">Delete</button>
    </div>

    
    <form id="delete-form-<?php echo e($task->id); ?>" action="<?php echo e(route('tasks.destroy', $task)); ?>" method="POST" style="display:none">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
    </form>
</article>
<?php /**PATH C:\Users\ProgHero\Desktop\task-manager\resources\views/components/task-card.blade.php ENDPATH**/ ?>