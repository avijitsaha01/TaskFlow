<?php $__env->startSection('content'); ?>
    <div class="top">
        <div class="title">
            <h1>Settings</h1>
            <p>Manage your profile, password and dashboard defaults.</p>
        </div>
        <a class="btn secondary" href="<?php echo e(route('dashboard')); ?>">&larr; Back to tasks</a>
    </div>

    <?php if($errors->any()): ?>
        <div class="alert error"><?php echo e($errors->first()); ?></div>
    <?php endif; ?>

    <div class="profile-summary">
        <div class="avatar"><?php echo e(strtoupper(substr($user->username, 0, 1))); ?></div>
        <div>
            <strong><?php echo e($user->username); ?></strong>
            <div class="profile-meta">
                <?php echo e($user->email); ?> &middot; <?php echo e($user->phone); ?> &middot;
                <?php echo e($taskCount); ?> <?php echo e(Str::plural('task', $taskCount)); ?> &middot;
                Joined <?php echo e($user->created_at->format('M Y')); ?>

            </div>
        </div>
    </div>

    <div class="settings-grid">
        
        <section class="panel settings-card">
            <div class="card-head">
                <h2>Profile</h2>
                <p>Your username is how you sign in and how you appear in the app.</p>
            </div>

            <form class="form" action="<?php echo e(route('settings.profile')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="form-group">
                    <label for="username">Username</label>
                    <input class="input" id="username" name="username" value="<?php echo e(old('username', $user->username)); ?>" required minlength="3" maxlength="50" autocomplete="username">
                    <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="error-text"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                    <label for="email">Email</label>
                    <input class="input" id="email" name="email" type="email" value="<?php echo e(old('email', $user->email)); ?>" required autocomplete="email">
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="error-text"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                    <label for="phone">Phone</label>
                    <input class="input" id="phone" name="phone" type="tel" value="<?php echo e(old('phone', $user->phone)); ?>" required autocomplete="tel">
                    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="error-text"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-actions">
                    <button class="btn" type="submit">Save profile</button>
                </div>
            </form>
        </section>

        
        <section class="panel settings-card">
            <div class="card-head">
                <h2>Password</h2>
                <p>Use at least 8 characters. You will stay signed in.</p>
            </div>

            <form class="form" action="<?php echo e(route('settings.password')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="form-group">
                    <label for="current_password">Current password</label>
                    <input class="input" id="current_password" name="current_password" type="password" required autocomplete="current-password">
                    <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="error-text"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                    <label for="new_password">New password</label>
                    <input class="input" id="new_password" name="password" type="password" required minlength="8" autocomplete="new-password">
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="error-text"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                    <label for="new_password_confirmation">Confirm new password</label>
                    <input class="input" id="new_password_confirmation" name="password_confirmation" type="password" required minlength="8" autocomplete="new-password">
                </div>

                <div class="form-actions">
                    <button class="btn" type="submit">Update password</button>
                </div>
            </form>
        </section>

        
        <section class="panel settings-card">
            <div class="card-head">
                <h2>Dashboard defaults</h2>
                <p>Choose what the task list shows when you open it.</p>
            </div>

            <form class="form" action="<?php echo e(route('settings.preferences')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="form-group">
                    <label for="default_filter">Default view</label>
                    <select class="input" id="default_filter" name="default_filter">
                        <?php $__currentLoopData = ['all' => 'All tasks', 'today' => 'Due today', 'active' => 'Active', 'completed' => 'Completed']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($value); ?>" <?php echo e(old('default_filter', $user->default_filter ?: 'all') === $value ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['default_filter'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="error-text"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                    <label for="default_sort">Default sort</label>
                    <select class="input" id="default_sort" name="default_sort">
                        <?php $__currentLoopData = ['newest' => 'Newest first', 'oldest' => 'Oldest first', 'priority' => 'Priority', 'due' => 'Due date']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($value); ?>" <?php echo e(old('default_sort', $user->default_sort ?: 'newest') === $value ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['default_sort'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="error-text"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-actions">
                    <button class="btn" type="submit">Save preferences</button>
                </div>
            </form>
        </section>

        
        <section class="panel settings-card danger-card">
            <div class="card-head">
                <h2>Delete account</h2>
                <p>This permanently removes your account and all <?php echo e($taskCount); ?> <?php echo e(Str::plural('task', $taskCount)); ?>. This cannot be undone.</p>
            </div>

            <form class="form" action="<?php echo e(route('settings.destroy')); ?>" method="POST" onsubmit="return confirm('Delete your account and all tasks? This cannot be undone.')">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>

                <div class="form-group">
                    <label for="delete_password">Confirm with your password</label>
                    <input class="input" id="delete_password" name="confirm_password" type="password" required autocomplete="current-password">
                    <?php $__errorArgs = ['confirm_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="error-text"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-actions">
                    <button class="btn danger" type="submit">Delete my account</button>
                </div>
            </form>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ProgHero\Desktop\task-manager\resources\views/settings/edit.blade.php ENDPATH**/ ?>