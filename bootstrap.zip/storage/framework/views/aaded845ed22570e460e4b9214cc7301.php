<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', 'Account'); ?> &mdash; TaskFlow</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap" rel="stylesheet">
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
</head>
<body>
    <main class="auth-wrap">
        <div class="auth-card">
            <div class="auth-brand">Task<span>Flow</span></div>

            <h1><?php echo $__env->yieldContent('heading'); ?></h1>
            <p class="auth-sub"><?php echo $__env->yieldContent('subheading'); ?></p>

            <?php if(session('success')): ?>
                <div class="alert success"><?php echo e(session('success')); ?></div>
            <?php endif; ?>
            <?php if(session('error')): ?>
                <div class="alert error"><?php echo e(session('error')); ?></div>
            <?php endif; ?>

            <?php if($errors->any()): ?>
                <div class="alert error"><?php echo e($errors->first()); ?></div>
            <?php endif; ?>

            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </main>
</body>
</html>
<?php /**PATH C:\Users\ProgHero\Desktop\task-manager\resources\views/layouts/auth.blade.php ENDPATH**/ ?>