<aside class="sidebar">
    <?php
        $viewParameters = array_filter(Arr::only(request()->query(), ['priority', 'sort', 'search']), 'is_string');
        $taskViews = [
            'all' => ['All tasks', '≡', $totalCount ?? null],
            'today' => ['Today', '◷', $todayCount ?? null],
            'active' => ['Active', '○', $activeCount ?? null],
            'completed' => ['Completed', '✓', $completedCount ?? null],
        ];
    ?>

    <a class="logo" href="<?php echo e(route('dashboard', ['filter' => 'all'])); ?>">
        <span class="brand-mark" aria-hidden="true">✓</span> TaskFlow
    </a>

    <nav class="nav" aria-label="Task views">
        <?php $__currentLoopData = $taskViews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $view => [$label, $icon, $count]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('dashboard', ['filter' => $view] + $viewParameters)); ?>"
                <?php if(($currentFilter ?? null) === $view): ?> class="active" aria-current="page" <?php endif; ?>>
                <span class="nav-ico" aria-hidden="true"><?php echo e($icon); ?></span>
                <span><?php echo e($label); ?></span>
                <?php if($count !== null): ?>
                    <small><?php echo e($count); ?></small>
                <?php endif; ?>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </nav>

    <div class="side-bottom">
        <div class="side-account">
            <span class="avatar-sm" aria-hidden="true"><?php echo e(strtoupper(substr(auth()->user()->username, 0, 1))); ?></span>

            <a class="side-user" href="<?php echo e(route('settings.edit')); ?>" title="Open account settings">
                <strong><?php echo e(auth()->user()->username); ?></strong>
            </a>

            <a class="gear-btn <?php echo e(request()->routeIs('settings.*') ? 'active' : ''); ?>"
               href="<?php echo e(route('settings.edit')); ?>"
               title="Settings"
               aria-label="Settings">
                <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"
                     stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                    <circle cx="12" cy="12" r="3"></circle>
                    <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.6a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9c0 .66.39 1.26 1 1.51H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"></path>
                </svg>
            </a>
        </div>

        <form action="<?php echo e(route('logout')); ?>" method="POST" style="margin:0">
            <?php echo csrf_field(); ?>
            <button type="submit" class="logout-btn">Sign out</button>
        </form>
    </div>
</aside>
<?php /**PATH C:\Users\ProgHero\Desktop\task-manager\resources\views/components/sidebar.blade.php ENDPATH**/ ?>