<?php $__env->startSection('title', 'Create account'); ?>
<?php $__env->startSection('heading', 'Create your space'); ?>
<?php $__env->startSection('subheading', 'Your tasks stay private to your account.'); ?>

<?php $__env->startSection('content'); ?>
    <form class="form" action="<?php echo e(route('register')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="form-group">
            <label for="username">Username</label>
            <input class="input" id="username" name="username" value="<?php echo e(old('username')); ?>" required minlength="3" maxlength="50" autocomplete="username">
        </div>

        <div class="form-group">
            <label for="email">Email</label>
            <input class="input" id="email" name="email" type="email" value="<?php echo e(old('email')); ?>" required autocomplete="email">
        </div>

        <div class="form-group">
            <label for="phone">Phone</label>
            <input class="input" id="phone" name="phone" type="tel" value="<?php echo e(old('phone')); ?>" placeholder="+15551234567" required autocomplete="tel">
        </div>

        <div class="form-group">
            <label for="password">Password</label>
            <input class="input" id="password" name="password" type="password" required minlength="8" autocomplete="new-password">
        </div>

        <div class="form-group">
            <label for="password_confirmation">Confirm password</label>
            <input class="input" id="password_confirmation" name="password_confirmation" type="password" required minlength="8" autocomplete="new-password">
        </div>

        <button class="btn" type="submit">Create account</button>
    </form>

    <p class="auth-foot">Already have an account? <a href="<?php echo e(route('login')); ?>">Sign in</a></p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ProgHero\Desktop\task-manager\resources\views/auth/register.blade.php ENDPATH**/ ?>