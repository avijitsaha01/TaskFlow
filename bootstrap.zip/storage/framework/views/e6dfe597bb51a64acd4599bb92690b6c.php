<?php $__env->startSection('title', 'Verify code'); ?>
<?php $__env->startSection('heading', 'Enter your code'); ?>
<?php $__env->startSection('subheading', 'Type the 6-digit code to continue.'); ?>

<?php $__env->startSection('content'); ?>
    <?php if(session('otp_code')): ?>
        <div class="otp-popup" id="otpPopup">
            <div class="otp-popup-head">
                <span>Verification code</span>
                <button type="button" class="otp-popup-close" onclick="document.getElementById('otpPopup').remove()">&times;</button>
            </div>
            <div class="otp-code"><?php echo e(session('otp_code')); ?></div>
            <p class="otp-note">
                This code is shown here for the local demo.
            </p>
        </div>
    <?php endif; ?>

    <form class="form" action="<?php echo e(route('password.verify')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="form-group">
            <label for="code">Verification code</label>
            <input class="input otp-input" id="code" name="code" inputmode="numeric" pattern="[0-9]{6}" maxlength="6" placeholder="000000" required autofocus autocomplete="one-time-code">
        </div>

        <button class="btn" type="submit">Verify code</button>
    </form>

    <form class="resend-form" action="<?php echo e(route('password.resend')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <button type="submit" class="link-button">Resend code</button>
        <span class="auth-foot">or <a href="<?php echo e(route('password.request')); ?>">start over</a></span>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ProgHero\Desktop\task-manager\resources\views/auth/verify-otp.blade.php ENDPATH**/ ?>