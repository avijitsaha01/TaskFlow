<?php $__env->startSection('content'); ?>
    <?php
        $calendarBase = Arr::except($dashboardParameters, ['month', 'date', 'page']);
        $prevMonth = $calendarMonth->copy()->subMonth()->format('Y-m');
        $nextMonth = $calendarMonth->copy()->addMonth()->format('Y-m');
        $monthName = $calendarMonth->format('F Y');
    ?>

    <header class="dash-head">
        <div>
            <div class="eyebrow"><?php echo e(now()->format('l, F j, Y')); ?></div>
            <h1>Hi, <?php echo e(auth()->user()->username); ?></h1>
        </div>

        <div class="dash-head-actions">
            <button class="btn btn-add" id="addBtn" type="button">
                <span class="btn-plus" aria-hidden="true">＋</span> Add task
            </button>
        </div>
    </header>

    <?php if($overdueCount > 0): ?>
        <a class="dash-alert"
           href="<?php echo e(route('dashboard', array_merge($calendarBase, ['filter' => 'active', 'due' => 'overdue', 'sort' => 'due']))); ?>">
            <strong><?php echo e($overdueCount); ?> overdue <?php echo e(Str::plural('task', $overdueCount)); ?></strong>
            <span class="alert-cta">Review overdue &rarr;</span>
        </a>
    <?php endif; ?>

    
    <section class="kpis" aria-label="Task overview">
        <article class="kpi">
            <p>Total tasks</p>
            <strong class="kpi-n"><?php echo e($totalCount); ?></strong>
        </article>

        <article class="kpi">
            <p>Active</p>
            <strong class="kpi-n"><?php echo e($activeCount); ?></strong>
            <span class="kpi-foot"><?php echo e($todayCount); ?> due today</span>
        </article>

        <article class="kpi">
            <p>Completed</p>
            <strong class="kpi-n"><?php echo e($completedCount); ?></strong>
            <span class="kpi-foot"><?php echo e($completedThisWeek); ?> this week</span>
        </article>

        <article class="kpi kpi-progress">
            <p>Progress</p>
            <strong class="kpi-n"><?php echo e($progressPercentage); ?>%</strong>
            <progress class="completion-meter" max="100" value="<?php echo e($progressPercentage); ?>" aria-label="Task completion"><?php echo e($progressPercentage); ?>%</progress>
        </article>
    </section>

    <div class="dash-grid">
        
        <section class="panel tasks-panel">
            <div class="panel-head">
                <div>
                    <h2>My Tasks</h2>
                    <p><?php echo e($tasks->count()); ?> <?php echo e(Str::plural('task', $tasks->count())); ?><?php echo e($currentFilter === 'all' ? '' : ' · '.ucfirst($currentFilter)); ?></p>
                </div>

            </div>

            <form id="filterForm" action="<?php echo e(route('dashboard')); ?>" method="GET">
                <?php if(isset($dashboardParameters['filter'])): ?>
                    <input type="hidden" name="filter" value="<?php echo e($currentFilter); ?>">
                <?php endif; ?>
                <?php if($currentDue): ?>
                    <input type="hidden" name="due" value="<?php echo e($currentDue); ?>">
                <?php endif; ?>
                <?php if(isset($dashboardParameters['month'])): ?>
                    <input type="hidden" name="month" value="<?php echo e($calendarMonth->format('Y-m')); ?>">
                <?php endif; ?>
                <?php if($selectedDate): ?>
                    <input type="hidden" name="date" value="<?php echo e($selectedDate->toDateString()); ?>">
                <?php endif; ?>

                <div class="toolbar">
                    <div class="search">
                        <span class="search-ico" aria-hidden="true">⌕</span>
                        <input class="input"
                               id="search"
                               name="search"
                               value="<?php echo e($searchQuery); ?>"
                               placeholder="Search tasks..."
                               aria-label="Search tasks">
                    </div>

                    <select class="input select-compact" id="priorityFilter" name="priority" aria-label="Filter by priority">
                        <option value="all" <?php echo e($currentPriority === 'all' ? 'selected' : ''); ?>>All priorities</option>
                        <option value="high" <?php echo e($currentPriority === 'high' ? 'selected' : ''); ?>>High</option>
                        <option value="medium" <?php echo e($currentPriority === 'medium' ? 'selected' : ''); ?>>Medium</option>
                        <option value="low" <?php echo e($currentPriority === 'low' ? 'selected' : ''); ?>>Low</option>
                    </select>

                    <select class="input select-compact" id="sort" name="sort" aria-label="Sort tasks">
                        <option value="newest" <?php echo e($currentSort === 'newest' ? 'selected' : ''); ?>>Newest</option>
                        <option value="oldest" <?php echo e($currentSort === 'oldest' ? 'selected' : ''); ?>>Oldest</option>
                        <option value="priority" <?php echo e($currentSort === 'priority' ? 'selected' : ''); ?>>Priority</option>
                        <option value="due" <?php echo e($currentSort === 'due' ? 'selected' : ''); ?>>Due date</option>
                    </select>
                </div>
            </form>

            <?php if($selectedDate || $currentDue || $searchQuery !== '' || $currentPriority !== 'all'): ?>
                <div class="active-filters">
                    <?php if($selectedDate): ?>
                        <span class="filter-pill">Due <?php echo e($selectedDate->format('M j, Y')); ?></span>
                    <?php endif; ?>
                    <?php if($currentDue === 'overdue'): ?>
                        <span class="filter-pill danger">Overdue</span>
                    <?php elseif($currentDue === 'today'): ?>
                        <span class="filter-pill">Due today</span>
                    <?php elseif($currentDue === 'week'): ?>
                        <span class="filter-pill">Next 7 days</span>
                    <?php endif; ?>
                    <?php if($searchQuery !== ''): ?>
                        <span class="filter-pill">“<?php echo e($searchQuery); ?>”</span>
                    <?php endif; ?>
                    <?php if($currentPriority !== 'all'): ?>
                        <span class="filter-pill"><?php echo e(ucfirst($currentPriority)); ?> priority</span>
                    <?php endif; ?>

                    <a class="clear-filters" href="<?php echo e(route('dashboard', Arr::except($dashboardParameters, ['date', 'due', 'search', 'priority', 'page']))); ?>">Clear filters</a>
                </div>
            <?php endif; ?>

            <div class="tasks" id="taskList">
                <?php $__empty_1 = true; $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php echo $__env->make('components.task-card', ['task' => $task], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="empty">
                        <b>No tasks found</b>
                        <span><?php echo e($totalCount > 0 ? 'Try a different search or filter.' : 'Add your first task to get started.'); ?></span>
                        <button class="btn secondary" type="button" onclick="openModal()">＋ Add a task</button>
                    </div>
                <?php endif; ?>
            </div>
        </section>

        
        <aside class="dash-side">
            <section class="panel calendar-panel" id="calendar" aria-label="Task calendar">
                <div class="calendar-head">
                    <div>
                        <h2><?php echo e($monthName); ?></h2>
                        <p><?php echo e($calendarTaskCount); ?> <?php echo e(Str::plural('task', $calendarTaskCount)); ?> scheduled</p>
                    </div>

                    <div class="calendar-nav">
                        <a href="<?php echo e(route('dashboard', array_merge($calendarBase, ['month' => $prevMonth]))); ?>"
                           class="cal-nav-btn" aria-label="Previous month" title="Previous month">&lsaquo;</a>
                        <a href="<?php echo e(route('dashboard', array_merge($calendarBase, ['month' => now()->format('Y-m')]))); ?>"
                           class="cal-today-btn">Today</a>
                        <a href="<?php echo e(route('dashboard', array_merge($calendarBase, ['month' => $nextMonth]))); ?>"
                           class="cal-nav-btn" aria-label="Next month" title="Next month">&rsaquo;</a>
                    </div>
                </div>

                <div class="calendar-weekdays" aria-hidden="true">
                    <?php $__currentLoopData = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $weekday): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span><?php echo e($weekday); ?></span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <div class="calendar-grid">
                    <?php $__currentLoopData = $calendarDays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="cal-day <?php echo e($day['in_month'] ? '' : 'outside'); ?> <?php echo e($day['is_today'] ? 'today' : ''); ?> <?php echo e($day['is_selected'] ? 'selected' : ''); ?> <?php echo e($day['tasks']->isNotEmpty() ? 'has-tasks' : ''); ?>">
                            <a class="cal-date"
                               href="<?php echo e(route('dashboard', array_merge($calendarBase, ['date' => $day['key'], 'month' => $day['date']->format('Y-m')]))); ?>"
                               title="Show tasks due <?php echo e($day['date']->format('M j, Y')); ?>"><?php echo e($day['date']->day); ?></a>

                            <div class="cal-tasks">
                                <?php $__currentLoopData = $day['tasks']->take(2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a class="cal-chip <?php echo e($task->priority); ?> <?php echo e($task->is_completed ? 'done' : ''); ?>"
                                       href="<?php echo e(route('tasks.show', $task)); ?>"
                                       title="<?php echo e($task->title); ?> — <?php echo e(ucfirst($task->priority)); ?> priority"><?php echo e($task->title); ?></a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <?php if($day['tasks']->count() > 2): ?>
                                    <a class="cal-more"
                                       href="<?php echo e(route('dashboard', array_merge($calendarBase, ['date' => $day['key'], 'month' => $day['date']->format('Y-m')]))); ?>"
                                       title="Show all <?php echo e($day['tasks']->count()); ?> tasks due this day">+<?php echo e($day['tasks']->count() - 2); ?> more</a>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <div class="calendar-legend">
                    <span><i class="legend-dot high"></i>High</span>
                    <span><i class="legend-dot medium"></i>Medium</span>
                    <span><i class="legend-dot low"></i>Low</span>
                    <span><i class="legend-dot done"></i>Done</span>
                </div>
            </section>

            <section class="panel upcoming-panel">
                <div class="panel-head compact">
                    <div>
                        <h2>Upcoming deadlines</h2>
                    </div>
                    <a class="muted-link" href="<?php echo e(route('dashboard', ['filter' => 'active', 'sort' => 'due'])); ?>">View all</a>
                </div>

                <?php $__empty_1 = true; $__currentLoopData = $upcomingTasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <a class="upcoming-item" href="<?php echo e(route('tasks.show', $task)); ?>">
                        <span class="up-bar <?php echo e($task->priority); ?>" aria-hidden="true"></span>
                        <span class="up-body">
                            <strong><?php echo e($task->title); ?></strong>
                            <span>
                                <?php if($task->due_date->isToday()): ?>
                                    Today
                                <?php elseif($task->due_date->isTomorrow()): ?>
                                    Tomorrow
                                <?php else: ?>
                                    <?php echo e($task->due_date->format('D, M j')); ?>

                                <?php endif; ?>
                            </span>
                        </span>
                        <span class="up-pri <?php echo e($task->priority); ?>"><?php echo e(ucfirst($task->priority)); ?></span>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="up-empty">
                        No upcoming deadlines.
                    </div>
                <?php endif; ?>
            </section>
        </aside>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ProgHero\Desktop\task-manager\resources\views/dashboard.blade.php ENDPATH**/ ?>