<?php if(session('success')): ?>
    <input type="hidden" id="flashMessage" value="<?php echo e(session('success')); ?>">
<?php elseif(session('error')): ?>
    <input type="hidden" id="flashMessage" value="<?php echo e(session('error')); ?>">
<?php endif; ?>

<div class="toast" id="toast"></div>
<?php /**PATH C:\Users\ProgHero\Desktop\task-manager\resources\views/components/toast.blade.php ENDPATH**/ ?>