<div class="modal-back <?php echo e($errors->any() ? 'show' : ''); ?>" id="modalBack" data-reopen="<?php echo e($errors->any() ? '1' : '0'); ?>">
    <div class="modal">
        <div class="modal-head">
            <h2 id="modalTitle"><?php echo e(old('_method') === 'PUT' ? 'Edit Task' : 'Add Task'); ?></h2>
            <button type="button" class="close" id="closeModal">&times;</button>
        </div>

        <form class="form" id="taskForm" action="<?php echo e(old('_method') === 'PUT' && old('task_id') ? route('tasks.update', old('task_id')) : route('tasks.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="_method" id="methodField" value="<?php echo e(old('_method', 'POST')); ?>">
            <input type="hidden" name="task_id" id="taskId" value="<?php echo e(old('task_id', '')); ?>">

            
            <div class="form-group">
                <label for="taskTitle">Task title</label>
                <input class="input <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                       id="taskTitle" 
                       name="title" 
                       value="<?php echo e(old('title')); ?>" 
                       required 
                       maxlength="100" 
                       placeholder="e.g. Finish project documentation">
                <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="error-text"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div class="form-group">
                <label for="taskDesc">Description</label>
                <textarea class="input <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                          id="taskDesc" 
                          name="description" 
                          rows="3" 
                          placeholder="Add a short description..."><?php echo e(old('description')); ?></textarea>
                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="error-text"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div class="row">
                <div class="form-group">
                    <label for="taskPriority">Priority</label>
                    <select class="input <?php $__errorArgs = ['priority'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="taskPriority" name="priority">
                        <option value="high" <?php echo e(old('priority') === 'high' ? 'selected' : ''); ?>>High</option>
                        <option value="medium" <?php echo e(old('priority', 'medium') === 'medium' ? 'selected' : ''); ?>>Medium</option>
                        <option value="low" <?php echo e(old('priority') === 'low' ? 'selected' : ''); ?>>Low</option>
                    </select>
                    <?php $__errorArgs = ['priority'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="error-text"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                    <label for="taskDue">Due date</label>
                    <input class="input <?php $__errorArgs = ['due_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                           type="date" 
                           id="taskDue" 
                           name="due_date" 
                           value="<?php echo e(old('due_date')); ?>">
                    <?php $__errorArgs = ['due_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="error-text"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            
            <div class="modal-actions">
                <button type="button" class="btn secondary" id="cancelBtn">Cancel</button>
                <button class="btn" type="submit">Save Task</button>
            </div>
        </form>
    </div>
</div>
<?php /**PATH C:\Users\ProgHero\Desktop\task-manager\resources\views/components/task-form-modal.blade.php ENDPATH**/ ?>