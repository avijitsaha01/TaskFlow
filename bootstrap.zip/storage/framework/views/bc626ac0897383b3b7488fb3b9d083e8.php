<?php $__env->startSection('title', 'Set new password'); ?>
<?php $__env->startSection('heading', 'Choose a new password'); ?>
<?php $__env->startSection('subheading', 'Use at least 8 characters.'); ?>

<?php $__env->startSection('content'); ?>
    <form class="form" action="<?php echo e(route('password.reset')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="form-group">
            <label for="password">New password</label>
            <input class="input" id="password" name="password" type="password" required minlength="8" autofocus autocomplete="new-password">
        </div>

        <div class="form-group">
            <label for="password_confirmation">Confirm new password</label>
            <input class="input" id="password_confirmation" name="password_confirmation" type="password" required minlength="8" autocomplete="new-password">
        </div>

        <button class="btn" type="submit">Update password</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ProgHero\Desktop\task-manager\resources\views/auth/reset-password.blade.php ENDPATH**/ ?>