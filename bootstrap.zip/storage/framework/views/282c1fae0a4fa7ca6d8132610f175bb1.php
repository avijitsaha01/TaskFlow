<?php $__env->startSection('content'); ?>
    <a href="<?php echo e(route('dashboard')); ?>" class="back-link">&larr; Back to Dashboard</a>

    <div class="detail-card">
        <div style="display:flex;justify-content:space-between;align-items:flex-start">
            <div>
                <h2><?php echo e($task->title); ?></h2>
                <div class="detail-meta">
                    <?php echo $__env->make('components.priority-badge', ['priority' => $task->priority], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <span>Status: <strong><?php echo e(ucfirst($task->status)); ?></strong></span>
                    <?php if($task->due_date): ?>
                        <span>Due: 📅 <?php echo e($task->due_date->format('F d, Y')); ?></span>
                    <?php endif; ?>
                    <span>Created: <?php echo e($task->created_at->format('M d, Y')); ?></span>
                </div>
            </div>

            <form action="<?php echo e(route('tasks.toggle', $task)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PATCH'); ?>
                <button type="submit" class="btn <?php echo e($task->is_completed ? 'secondary' : ''); ?>">
                    <?php echo e($task->is_completed ? 'Reopen Task' : 'Mark Completed'); ?>

                </button>
            </form>
        </div>

        <?php if($task->description): ?>
            <div class="detail-body">
                <strong>Description:</strong>
                <p style="margin-top:6px;white-space:pre-wrap"><?php echo e($task->description); ?></p>
            </div>
        <?php else: ?>
            <div class="detail-body" style="color:var(--muted)">
                <em>No description provided.</em>
            </div>
        <?php endif; ?>

        <div class="detail-actions">
            <button type="button" class="btn secondary" onclick="openModal(<?php echo e($task->id); ?>)" data-task-id="<?php echo e($task->id); ?>"
                data-title="<?php echo e($task->title); ?>"
                data-description="<?php echo e($task->description); ?>"
                data-priority="<?php echo e($task->priority); ?>"
                data-due="<?php echo e($task->due_date ? $task->due_date->format('Y-m-d') : ''); ?>">✎ Edit Task</button>
            <form action="<?php echo e(route('tasks.destroy', $task)); ?>" method="POST" onsubmit="return confirm('Delete this task?')" style="margin:0">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn danger">⌫ Delete Task</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ProgHero\Desktop\task-manager\resources\views/tasks/show.blade.php ENDPATH**/ ?>