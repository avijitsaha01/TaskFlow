<?php $__env->startSection('title', 'Sign in'); ?>
<?php $__env->startSection('heading', 'Welcome back'); ?>
<?php $__env->startSection('subheading', 'Sign in with your email, username or phone.'); ?>

<?php $__env->startSection('content'); ?>
    <form class="form" action="<?php echo e(route('login')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="form-group">
            <label for="login">Email, username or phone</label>
            <input class="input" id="login" name="login" value="<?php echo e(old('login')); ?>" required autofocus autocomplete="username">
        </div>

        <div class="form-group">
            <label for="password">Password</label>
            <input class="input" id="password" name="password" type="password" required autocomplete="current-password">
        </div>

        <label class="check-line">
            <input type="checkbox" name="remember" value="1" <?php echo e(old('remember') ? 'checked' : ''); ?>>
            Remember me
        </label>

        <button class="btn" type="submit">Sign in</button>
    </form>

    <p class="auth-foot">
        <?php if(\App\Http\Middleware\EnsureDemoPasswordResetIsEnabled::enabled()): ?>
            <a href="<?php echo e(route('password.request')); ?>">Forgot password?</a><br>
        <?php endif; ?>
        No account? <a href="<?php echo e(route('register')); ?>">Create one</a>
    </p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ProgHero\Desktop\task-manager\resources\views/auth/login.blade.php ENDPATH**/ ?>